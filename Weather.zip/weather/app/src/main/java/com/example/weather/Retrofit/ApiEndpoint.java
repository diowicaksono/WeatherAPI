package com.example.weather.Retrofit;

import com.example.weather.Model.ForecastModel;
import com.example.weather.Model.WeatherModel;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiEndpoint {
    @GET("current.json?key=e1aa8c03d8044c74bff52252210906&q=Jakarta&aqi=yes")
    Call<WeatherModel> getData();
    @GET("forecast.json?key=e1aa8c03d8044c74bff52252210906&q=jakarta&days=3&aqi=no&alerts=no")
    Call<WeatherModel> getForecast();
}
